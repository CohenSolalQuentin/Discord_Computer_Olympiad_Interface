from discord_interface.player.model.bot_launcher import gpt_bot_starting

if '__main__' == __name__:
    gpt_bot_starting(program_name='python3', program_arguments='player/instances/autres/gtp_random_ai_bis.py', program_directory='')